package com.example.gms.servlet;

import com.example.gms.bean.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.gms.service.loginService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import java.io.IOException;

@WebServlet(name = "registerServlet", value = "/registerServlet")
public class registerServlet extends HttpServlet{
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        //接收表单信息
        String id=req.getParameter("id");
        String name=req.getParameter("name");
        String password=req.getParameter("password");
        String rppwd=req.getParameter("rppwd");
        String sex=req.getParameter("sex");
        String Age=req.getParameter("age");
        int age=Integer.parseInt(Age);
        String email=req.getParameter("email");
        String phone= req.getParameter("phone");
        System.out.println(id+" "+name+" "+password+" "+rppwd+" "+sex+" "+age+" "+email+" "+phone);
        //判断注册异常

        if(id==null||id.trim().isEmpty()){
            req.setAttribute("registError", "学号不能为空");
            req.getRequestDispatcher("/login/register.jsp").forward(req, resp);
            return;
        }
        if(name==null||name.trim().isEmpty()){
            req.setAttribute("registError", "用户名不能为空");
            req.getRequestDispatcher("/login/register.jsp").forward(req, resp);
            return;
        }
        if(password==null||password.trim().isEmpty()){
            req.setAttribute("registError", "密码不能为空");
            req.getRequestDispatcher("/login/register.jsp").forward(req, resp);
            return;
        }
        if(!password.equals(rppwd)){
            req.setAttribute("registError", "密码不一致");
            req.getRequestDispatcher("/login/register.jsp").forward(req, resp);
            return;
        }
        User user=new User(id,password,name,sex,age,email,phone);
//        ObjectMapper mapper = new ObjectMapper(); //Jackson的核心类
//        String json = mapper.writeValueAsString(user);
//        System.out.println(json);//测试
        loginService ss=new loginService();
        User existUser=ss.register(user);
        if(existUser==null){
            req.setAttribute("registError", "该用户已注册");
            req.getRequestDispatcher("/login/register.jsp").forward(req, resp);
            return;
        }
        else {
            HttpSession session = req.getSession();
            session.setAttribute("user", existUser);
            req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
        }
    }
}
