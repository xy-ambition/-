package com.example.gms.servlet;
import com.example.gms.bean.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.example.gms.service.loginService;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import javax.servlet.*;
import javax.servlet.http.HttpServlet;
import java.io.IOException;
import javax.servlet.annotation.WebServlet;

@WebServlet(name = "loginServlet", value = "/loginServlet")
public class loginServlet extends HttpServlet{
    @Override
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setCharacterEncoding("utf-8");
        resp.setContentType("text/html;charset=utf-8");
        //获取参数
        String id=req.getParameter("id");
        String password=req.getParameter("password");
        String verifycode=req.getParameter("verifycode");
        //设置回显
        req.setAttribute("id",id);
        req.setAttribute("password", password);
        req.setAttribute("verifycode", verifycode);
        //获取验证码
        String svc =(String) req.getSession().getAttribute("sessionverify");
        if(id==null||id.trim().isEmpty()){
            req.setAttribute("loginError", "*请输入账号");
            req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
            return;
        }
        if(password==null||password.trim().isEmpty()){
            req.setAttribute("loginError", "*请输入密码");
            req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
            return;
        }
        if(!svc.equalsIgnoreCase(verifycode)){
            req.setAttribute("loginError", "* 验证码错误");
            req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
            return;
        }
        loginService ss=new loginService();
        User user= null;
        try {
            user = ss.selectOneByID(id);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if(user!=null){
            if(user.getPassword().equals(password)){
                req.getSession().setAttribute("user", user);
                resp.sendRedirect("/page/show.jsp");
            }else {
                req.setAttribute("loginError", "* 密码错误");
                req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
            }
        }else {
            req.setAttribute("loginError", "* 用户不存在");
            req.getRequestDispatcher("/login/login.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        super.doGet(req, resp);
    }
}
