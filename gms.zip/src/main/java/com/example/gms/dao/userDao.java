package com.example.gms.dao;
import com.example.gms.bean.User;
import com.example.gms.util.JNDIUtils;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class userDao {
    Connection conn = null;
    PreparedStatement stmt = null;
    Statement stmt2=null;
    ResultSet rs = null;
    String tableName="user";
    public User register(User user) { //登录
        User existUser=null;
        try {
            conn = JNDIUtils.getConnection();		//JNDI DataSource数据源方式

            String sql = "select * from "+tableName+" where user_id=?";//
            stmt = conn.prepareStatement(sql);	//将sql发送给数据库进行编译

            //设置sql参数
            String id=user.getId();
            String password=user.getPassword();
            String name=user.getName();
            String sex=user.getSex();
            int age=user.getAge();
            String email=user.getEmail();
            String phone=user.getPhone();
            stmt.setString(1, id);
            rs = stmt.executeQuery();			//执行sql
            if(rs.next()){
                System.out.println("该用户已经存在，请更换用户名，重新注册！");
                return null;
            }else { //用户名不存在
                //注册用户，将用户名和密码写入数据库
                stmt2=conn.createStatement();
                sql ="INSERT INTO "+tableName+
                        "(user_id,user_password,user_name,user_sex,user_age,user_email,user_phone) values('"
                        +id+"','"+password+"','"+name+"','"+sex+"',"+age+",'"+email+"','"+phone+
                        "');";
                System.out.println("\n带参数的SQL："+sql);
                int row=stmt2.executeUpdate(sql);//将姓名和密码写入数据库
                System.out.println("insert row="+row);
                existUser=new User(id, password,name,sex,age,email,phone);//创建一个对象的目的仅仅是为了给register.jsp一个信息判断
                stmt2.close();//释放stmt2
            }
            JNDIUtils.release(rs, stmt, conn);	//释放资源，JNDI数据源方式
        } catch (Exception e) {
            e.printStackTrace();
        }
        return existUser;
    }
    public User selectOneByID(String id) throws Exception {
        User existUser=null;
        conn = JNDIUtils.getConnection();		//JNDI DataSource数据源方式
        List<User> list = new ArrayList<>();
        String sql = "select * from "+tableName+" where user_id=?";//
        try {
        stmt = conn.prepareStatement(sql);	//将sql发送给数据库进行编译
        stmt.setString(1, id);
        rs = stmt.executeQuery();			//执行sql
        list=resultSetToBean(rs);
        } catch (SQLException e) {
            e.printStackTrace();
        }finally {
            JNDIUtils.release(rs, stmt, conn);	//释放资源，JNDI数据源方式
        }
        return list.isEmpty()?null:list.get(0);
    }

    private static List<User> resultSetToBean(ResultSet rs) throws SQLException {
        List<User> list = new ArrayList<>();
        while (rs.next()){
            User user = new User();
            user.setId(rs.getString("user_id"));
            user.setPassword(rs.getString("user_password"));
            user.setName(rs.getString("user_name"));
            user.setSex(rs.getString("user_sex"));
            user.setAge(rs.getInt("user_age"));
            user.setEmail(rs.getString("user_email"));
            user.setPhone(rs.getString("user_phone"));
            list.add(user);
        }
        return list;
    }
}
