package com.example.gms.bean;

public class User {
    String id;
    String password;
    String name;
    String sex;
    int age;
    String email;
    String phone;
    public User(){

    }
    public  User(String id,String password){
        this.id=id;
        this.password=password;
    }
    public User(String id,String password,String name,String sex,int age,String email,String phone){
        this.id=id;
        this.password=password;
        this.name=name;
        this.sex=sex;
        this.age=age;
        this.email=email;
        this.phone=phone;
    }
    public String getId() {
        return id;
    }

    public String getPassword() {
        return password;
    }

    public String getName() {
        return name;
    }

    public String getSex() {
        return sex;
    }

    public int getAge() {
        return age;
    }

    public String getEmail() {
        return email;
    }

    public String getPhone() {
        return phone;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }
}
