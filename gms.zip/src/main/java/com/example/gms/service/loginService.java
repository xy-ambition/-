package com.example.gms.service;
import com.example.gms.bean.User;
import com.example.gms.dao.userDao;

public class loginService {
    public User register(User user) {
        userDao dao = new userDao(); //查询， 将 user对象传递 DAO
        return dao.register(user);
    }
    public User selectOneByID(String id) throws Exception {
        userDao dao = new userDao(); //查询， 将 user对象传递 DAO
        return dao.selectOneByID(id);
    }
}
